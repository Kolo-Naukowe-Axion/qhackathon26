"""Recheck saved solver evidence and optionally export an official schedule."""

import argparse
import json
from pathlib import Path

from .artifacts import assess_samples, digest, write_json
from .stage1 import ROOT, decode, exact_reference, validate


def verify_run(directory):
    directory = Path(directory)
    report, model, records, schedule = [json.loads((directory / name).read_text()) for name in
                                        ("run.json", "model.json", "samples.json", "schedule.json")]
    name = report["instance"]
    if name not in ("instance_2x2", "instance_3x3"):
        raise ValueError("Unknown instance")
    instance = json.loads((ROOT / "instances" / f"{name}.json").read_text())
    if report["model_sha256"] != digest(model) or report["instance_sha256"] != digest(instance):
        raise ValueError("Model or instance hash mismatch")
    recomputed = assess_samples(instance, model, records)
    if recomputed != records:
        raise ValueError("Stored sample diagnostics differ from recomputed checks")
    feasible = [r for r in recomputed if r["feasible"]]
    if not feasible or not report["accepted"]:
        raise ValueError("No accepted feasible sample")
    selected = min(feasible, key=lambda r: (r["makespan"], -r["count"], r["bits"]))
    if schedule != dict(instance=name, method=report["method"], makespan=selected["makespan"], schedule=decode(model, selected["bits"])):
        raise ValueError("Official schedule differs from the selected actual sample")
    if validate(instance, schedule["schedule"], schedule["makespan"]):
        raise ValueError("Official schedule failed independent feasibility checking")
    total, accepted = sum(r["count"] for r in recomputed), sum(r["count"] for r in feasible)
    if report["total_samples"] != total or report["feasible_samples"] != accepted or report["feasible_rate"] != accepted / total:
        raise ValueError("Reported sample counts differ from retained samples")
    optimum = exact_reference(instance)["makespan"]
    return schedule, dict(verified=True, instance=name, method=report["method"], makespan=schedule["makespan"],
                          exact_reference=optimum, optimality_gap=schedule["makespan"] - optimum,
                          model_sha256=digest(model), scope="Saved evidence consistency and independent feasibility; not external authentication")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--export", type=Path, help="Write the verified official schedule here")
    args = parser.parse_args()
    schedule, report = verify_run(args.run)
    if args.export:
        write_json(args.export, schedule)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
